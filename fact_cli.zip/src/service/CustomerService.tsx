import Customer from '../models/Customer' ;
import AuthenticationService from './AuthenticationService';


export default class CustomerService {

    static customer:Customer[] ;
  
   
    static getCustomer(): Promise<Customer[]> {
      
            return fetch('http://localhost:8080/clientf/all', {
                method: "GET",
                headers: {'Authorization': AuthenticationService.jwt }
              })
            .then(response => response.json())
            .catch(error => this.handleError(error));
        
    }
    static deleteCustomer(id:number): Promise<Customer[]> {
      
        return fetch(`http://localhost:8080/client/${id}`, {
            method: "DELETE",
            headers: {'Authorization': AuthenticationService.jwt }
          })
        .then(response => response.json())
        .catch(error => this.handleError(error));
    
}
  

    static isEmpty(data: Object): boolean {
      return Object.keys(data).length === 0;
    }
  
    static handleError(error: Error): void {
      console.error(error);
    }
  }