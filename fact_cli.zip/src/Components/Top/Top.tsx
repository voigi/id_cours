import React from 'react';
import Avatar from '@mui/material/Avatar';
import './Top.css';

const Top = () => {

    return (
        
        <div className="top">
    <Avatar className="imgContainer"
  alt="picture"
  src="https://external-preview.redd.it/rnlgXbCLhppTaPYwEfznocQOXNI0j8tvSpBRb23DVac.jpg?auto=webp&s=df0a150e50f8c1d5cd5dc72b0cd167325556570f"/>
            <h1 className='name'>poutine Bear-rider</h1>
        </div>
    );
};
export default Top;

