import { NavLink } from "react-router-dom";
import { useState } from "react";
import Top from "./../Top/Top";
import DensityMediumIcon from "@mui/icons-material/DensityMedium";
import DashboardIcon from "@mui/icons-material/Dashboard";
import GroupIcon from "@mui/icons-material/Group";
import FileCopyIcon from "@mui/icons-material/FileCopy";
import ProductionQuantityLimitsIcon from "@mui/icons-material/ProductionQuantityLimits";
import PaymentIcon from "@mui/icons-material/Payment";
import LogoutIcon from "@mui/icons-material/Logout";
import "./SideBar.css";

const Sidebar = ({ children, ...props }: any) => {
  const [isOpen, setIsOpen] = useState(false);
  const toggle = () => setIsOpen(!isOpen);
  const menuItem = [
    {
      path: "/dashboard",
      name: "Dashboard",
      icon: <DashboardIcon />,
    },
    {
      path: "/customer",
      name: "Customer",
      icon: <GroupIcon />,
    },
    {
      path: "/invoice",
      name: "Invoice",
      icon: <FileCopyIcon />,
    },
    {
      path: "/product",
      name: "Product",
      icon: <ProductionQuantityLimitsIcon />,
    },
    {
      path: "/financial",
      name: "Financial",
      icon: <PaymentIcon />,
    },
    {
      path: "/",
      name: "Logout",
      icon: <LogoutIcon />,
    },
  ];

  return (
    <div className="container">
      <div style={{ width: isOpen ? "250px" : "50px" }} className="sidebar">
        <div className="top_section">
          <div style={{ marginLeft: isOpen ? "50px" : "0px" }} className="bars">
            <DensityMediumIcon onClick={toggle} />
          </div>
          <div
            style={{ display: isOpen ? "block" : "none" }}
            className="profil"
          >
            <Top />
          </div>
        </div>
        {menuItem.map((item, index) => (
          <NavLink to={item.path} key={index} className="link">
            <div className="icon">{item.icon}</div>
            <div
              style={{ display: isOpen ? "block" : "none" }}
              className="link_text"
            >
              {item.name}
            </div>
          </NavLink>
        ))}
      </div>
      <main>{children}</main>
    </div>
  );
};
export default Sidebar;
