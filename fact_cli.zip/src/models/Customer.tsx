export default class Customer {

    id : number;
    address: string;
    zip: string;
    tradename: string;
    website: string;
    email : string;
    phone: string;
    mobile: string;
    city: string;
    facture : number;
    paye: number;
    difference: number;
    pourcentage: number;
    

    constructor(
        id:  number ,
        address: string,
        zip: string,
        tradename: string,
        website: string,
        email: string,
        phone: string,
        mobile: string,
        city: string,
        facture : number,
        paye: number,
        difference: number,
        pourcentage: number

    ){
        this.id= id;
        this.address=address;
        this.zip= zip;
        this.tradename=tradename;
        this.website= website;
        this.email=email;
        this.phone= phone;
        this.mobile= mobile;
        this.city= city;
        this. facture = facture,
        this .paye = paye,
        this .difference = difference,
        this.pourcentage = pourcentage
    }
}