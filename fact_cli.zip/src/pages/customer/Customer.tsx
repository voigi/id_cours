import React, {  useEffect, useState } from 'react';
import { Box, Button } from '@mui/material';
import { DataGrid, GridActionsCellItem } from '@mui/x-data-grid';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import CustomerService from '../../service/CustomerService';
import Custo from '../../models/Customer';
import './Customer.css';
import { useNavigate } from 'react-router-dom';

const Customer = () => {

  const navigate = useNavigate();

  const navigateToform = () => {
    
    navigate('/customerform');
  };

  const rows = [

    {
      "id": 1,
      "address": "8 rue des jardins",
      "zip": "67900",
      "tradename": "Microsoft",
      "website": "Msn.com",
      "email": "mimi@caramail.com",
      "phone": "098777755544",
      "mobile": "06348977778",
      "city": "Tours"
  },
  {
      "id": 2,
      "address": "38 rue des fleurs",
      "zip": "67900",
      "tradename": "Ploom",
      "website": "Poom.com",
      "email": "poom@caramail.com",
      "phone": "0987777675544",
      "mobile": "0634567778",
      "city": "Roubaix"
  },
  {
      "id": 4,
      "address": "124 rue des girafe",
      "zip": "67900",
      "tradename": "Proum",
      "website": "Pim.com",
      "email": "pim@caramail.com",
      "phone": "0987755544",
      "mobile": "0634567878",
      "city": "Tourcoing"
  },
  {
      "id": 7,
      "address": "125 rue des girafe",
      "zip": "67900",
      "tradename": "Pom",
      "website": "Pim.com",
      "email": "pim@caramail.com",
      "phone": "0987755544",
      "mobile": "0634567878",
      "city": "Vannes"
  }

  ]

    for(var i = 0; i < rows.length; i++){
        console.log ("C" + rows[i].id.toString().padStart(5, '0'));      
    }
 


    const onDelete = (customer: any) => {
      CustomerService.deleteCustomer(customer);
    };
  
 
    
 const columns = [

      {
          field: 'id',
          headerName: 'ReferenceClient',
          flex: 3.5,
          cellClassName: 'ref-column--cell',                
            },    
      {
        field: 'tradename',
        headerName: 'Client',
        flex: 4,
        cellClassName: 'tradename-column--cell',
      },
      {
        field: 'address',
        headerName: 'Adresse',
        flex: 9,
        cellClassName: 'address-column--cell',
      },
      {
          field: 'zip',
          headerName: 'Code Postal',
          flex: 4,
          cellClassName: 'zip-column--cell',
        },
        {
          field: 'city',
          headerName: 'Ville',
          flex: 4,
          cellClassName: 'city-column--cell',
        },
         {
        field: 'phone',
        headerName: 'Telephone fixe',
        flex: 7,
        cellClassName: 'phone-column--cell',
      },
      {
        field: 'mobile',
        headerName: 'Telephone mobile',
        flex: 6.5,
        cellClassName: 'mobile-column--cell',
      },
      {
          field: 'email',
          headerName: 'E-mail',
          flex: 9,
          cellClassName: 'email-column--cell',
        },
        {
          field: 'website',
          headerName: 'Site Internet',
          flex: 5,
          cellClassName: 'website-column--cell',
        },
        {
          field: 'paye',
          headerName: 'Payé',
          flex: 6.5,
          cellClassName: 'paye-column--cell',
        },
        {
          field: 'facture',
          headerName: 'Facturé',
          flex: 6.5,
          cellClassName: 'facturé-column--cell',
        },
        {
            field: 'difference',
            headerName: 'Reste a payer',
            flex: 6.5,
            cellClassName: 'reste-column--cell',
          },
          {
            field: 'pourcentage',
            headerName: 'Pourcentage',
            flex: 4.5,
            cellClassName: 'website-column--cell',
          },
      {
        field: 'actions',
        headerName: 'Actions',
        type:'actions',
        flex: 5,
        cellClassName: 'action-column--cell',
        getActions: () => [
          <GridActionsCellItem
            icon={<EditIcon />}
            label="Modifier"
            onClick={navigateToform}
            showInMenu
          />,
          <GridActionsCellItem
            icon={<DeleteIcon />}
            label="Supprimer"
            onClick={onDelete}
            showInMenu
          />
         
        ] 
  
        
      },
    ];
    const [customer, setCustomer] = useState<Custo[]>([]);

    useEffect(() => {
      CustomerService.getCustomer().then(customers => setCustomer(customers));
    }, []);

    return (
      <><Button type="button"className='create-button' variant="contained" >Creer</Button><Box m="20px">
        <Box m="40px 0 0 0" height="75vh">
          <DataGrid rows={customer} columns={columns} />
        </Box>
      </Box></>
    );

};

export default Customer;