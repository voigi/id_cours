import { Box, Button, Grid, TextField } from "@mui/material";
import React from "react";
import "./Customer.css";
import { useFormik } from "formik";
import * as Yup from "yup";

const validationSchema = Yup.object({
  tradename: Yup.string()

    .max(80, "Le nom de l'entreprise est trop long")
    .required("Le nom de l'entreprise est obligatoire "),
  address: Yup.string()
    .max(100, "L'adresse est trop longue")
    .required("L'adresse est obligatoire"),

  zip: Yup.string()

    .max(5, "Le code postal est trop long")
    .required("Le code postal est obligatoire"),
  town: Yup.string()

    .max(80, "La ville est trop longue")
    .required("La ville est obligatoire"),
  email: Yup.string()
    .email("Entrez un email valide")
    .required("l'Email est requis"),

  website: Yup.string().max(100, "Le site internet est trop long"),

  phone: Yup.string().max(15, "Le telephone fixe est trop long"),

  mobile: Yup.string().max(15, "Le telephone mobile est trop long"),
});
function Customer_form() {
  const formik = useFormik({
    initialValues: {
      tradename: "",
      address: "",
      zip: "",
      town: "",
      email: "",
      website: "",
      phone: "",
      mobile: "",
    },
    onSubmit: (values) => {
      console.log(JSON.stringify(values));
    },
    validationSchema: validationSchema,
  });
  return (
    <div>
      <form onSubmit={formik.handleSubmit}>
        <Grid container className="test" rowGap={2}>
          <Grid xs={12}>
            <TextField
              id="tradename"
              label="Nom de l'entreprise"
              variant="filled"
              style={{ width: "98%" }}
              value={formik.values.tradename}
              onChange={formik.handleChange}
              error={
                formik.touched.tradename && Boolean(formik.errors.tradename)
              }
              helperText={formik.touched.tradename && formik.errors.tradename}
            />
          </Grid>
          <Grid xs={8}>
            <TextField
              id="address"
              label="Adresse"
              variant="filled"
              style={{ width: "100%" }}
              value={formik.values.address}
              onChange={formik.handleChange}
              error={formik.touched.address && Boolean(formik.errors.address)}
              helperText={formik.touched.address && formik.errors.address}
            />
          </Grid>
          <Grid xs={4}></Grid>
          <Grid xs={6}>
            <TextField
              id="zip"
              label="Code Postal"
              variant="filled"
              style={{ width: "95%" }}
              value={formik.values.zip}
              onChange={formik.handleChange}
              error={formik.touched.zip && Boolean(formik.errors.zip)}
              helperText={formik.touched.zip && formik.errors.zip}
            />
          </Grid>
          <Grid xs={6}>
            <TextField
              id="town"
              label="Ville"
              style={{ width: "95%" }}
              variant="filled"
              value={formik.values.town}
              onChange={formik.handleChange}
              error={formik.touched.town && Boolean(formik.errors.town)}
              helperText={formik.touched.town && formik.errors.town}
            />
          </Grid>
          <Grid xs={6}>
            <TextField
              id="email"
              label="e-mail"
              style={{ width: "95%" }}
              variant="filled"
              value={formik.values.email}
              onChange={formik.handleChange}
              error={formik.touched.email && Boolean(formik.errors.email)}
              helperText={formik.touched.email && formik.errors.email}
            />
          </Grid>
          <Grid xs={6}>
            <TextField
              id="website"
              label="Site internet"
              variant="filled"
              style={{ width: "95%" }}
              value={formik.values.website}
              onChange={formik.handleChange}
              error={formik.touched.website && Boolean(formik.errors.website)}
              helperText={formik.touched.website && formik.errors.website}
            />
          </Grid>
          <Grid xs={6}>
            <TextField
              id="phone"
              label="Téléphone fixe"
              variant="filled"
              style={{ width: "95%" }}
              value={formik.values.phone}
              onChange={formik.handleChange}
              error={formik.touched.phone && Boolean(formik.errors.phone)}
              helperText={formik.touched.phone && formik.errors.phone}
            />
          </Grid>
          <Grid xs={6}>
            <TextField
              id="mobile"
              label="Téléphone mobile"
              variant="filled"
              style={{ width: "95%" }}
              value={formik.values.mobile}
              onChange={formik.handleChange}
              error={formik.touched.mobile && Boolean(formik.errors.mobile)}
              helperText={formik.touched.mobile && formik.errors.mobile}
            />
          </Grid>
        </Grid>
        <Button color="primary" variant="contained" type="submit">
          Submit
        </Button>
      </form>
    </div>
  );
}

export default Customer_form;
