import React from 'react';

const Product = () => {
    return (
        <div>
               <h1>product</h1>
        </div>
    );
};

export default Product;