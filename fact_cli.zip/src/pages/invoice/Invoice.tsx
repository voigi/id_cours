import React from 'react';


const Invoice = () => {
    return (
        <div>
               <h1>invoice</h1>
        </div>
    );
};

export default Invoice;