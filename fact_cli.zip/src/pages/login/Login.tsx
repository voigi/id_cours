import { Visibility, VisibilityOff } from "@mui/icons-material";
import Button from "@mui/material/Button";
import FormControl from "@mui/material/FormControl";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import InputLabel from "@mui/material/InputLabel";
import OutlinedInput from "@mui/material/OutlinedInput";
import TextField from "@mui/material/TextField";
import { useFormik } from "formik";
import * as Yup from "yup";
import React from "react";
import "./Login.css";
import { FormHelperText } from "@mui/material";
import { useNavigate } from "react-router-dom";
import AuthentificationService from "./../../service/AuthenticationService";

const Login = () => {
  const navigate = useNavigate();

  // REGLES DE GESTION
  const validationSchema = Yup.object().shape({
    username: Yup.string()
      .min(4, "L'identifiant est trop court")
      .max(30, "L'identifiant est trop long")
      .required("L'identifiant est obligatoire"),
    password: Yup.string()
      .min(6, "Le mot de passe est trop court")
      .max(20, "Le mot de passe est trop long")
      .required("Le mot de passe est obligatoire"),
  });

  // VALIDATION FORMIK
  const formik = useFormik({
    initialValues: {
      username: "",
      password: "",
    },
    onSubmit: (values) => {
      console.log(JSON.stringify(values));

      AuthentificationService.login(values.username, values.password).then(
        (isAuthenticated: any) => {
          if (!isAuthenticated) {
            return;
          }
          navigate("/dashboard");
        }
      );
    },
    validationSchema: validationSchema,
  });

  // CONSTANTES POUR LE PASSWORD
  const [showPassword, setShowPassword] = React.useState(false);
  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  return (
    <div className="container">
      <div className="loginContainer">
        {/* LOGO */}
        <h1 className="log">Login</h1>
        {/* FORMULAIRE DE CONNEXION */}
        <form onSubmit={formik.handleSubmit}>
          <div className="loginInput">
            {/* USERNAME */}
            <TextField
              id="username"
              label="identifiant"
              variant="outlined"
              className="usernameInput"
              name="username"
              margin="dense"
              fullWidth
              value={formik.values.username}
              onChange={formik.handleChange}
              error={formik.touched.username && Boolean(formik.errors.username)}
              helperText={formik.touched.username && formik.errors.username}
            />
            {/* PASSWORD */}
            <FormControl
              fullWidth
              margin="normal"
              variant="outlined"
              className="passwordInput"
              error={formik.touched.password && Boolean(formik.errors.password)}
            >
              <InputLabel htmlFor="password">mot de passe</InputLabel>
              <OutlinedInput
                id="password"
                type={showPassword ? "text" : "password"}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      onMouseDown={handleMouseDownPassword}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                }
                label="mot de passe"
                value={formik.values.password}
                onChange={formik.handleChange}
              />
              <FormHelperText>
                {formik.touched.password && formik.errors.password}
              </FormHelperText>
            </FormControl>
            {/* BUTTON VALIDATION */}
            <Button variant="outlined" className="loginButton" type="submit">
              Valider
            </Button>
            {/* MESSAGE D'ERREUR => Connexion impossible */}
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
