import React from 'react';

const Financial = () => {
    return (
        <div>
               <h1>financial</h1>
        </div>
    );
};

export default Financial;