package com.example.client.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactDTO {

	private Long id;
	private String valeur;
	private ClientDTO client;
	private ContactTypeDTO type;

	public ContactDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ContactDTO(Long id, String valeur, ContactTypeDTO type) {
		super();
		this.id = id;
		this.valeur = valeur;
		this.type = type;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getValeur() {
		return valeur;
	}

	public void setValeur(String valeur) {
		this.valeur = valeur;
	}

	public ClientDTO getClient() {
		return client;
	}

	public void setClient(ClientDTO client) {
		this.client = client;
	}

	public ContactTypeDTO getType() {
		return type;
	}

	public void setType(ContactTypeDTO type) {
		this.type = type;
	}

}
