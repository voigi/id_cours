package com.example.client.service;

import java.util.List;

import com.example.client.core.domain.Client;

public interface IClientService {

	public List<Client> getAllClients();

	public void deleteCustomer(long id);

}
