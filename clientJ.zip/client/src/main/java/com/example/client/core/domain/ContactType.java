/**
 * 
 */
package com.example.client.core.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author voigi
 *
 */
@Entity
@Table(name = "type_contact")
public class ContactType {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "tco_id")
	private Long id;

	@Column(name = "tco_libelle")
	private String libelle;

	public ContactType() {
		super();

	}

	public ContactType(Long id, String libelle) {
		super();
		this.id = id;
		this.libelle = libelle;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

}
