/**
 * 
 */
package com.example.client.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.client.dto.ClientDTO;
import com.example.client.dto.mapper.ClientMapper;
import com.example.client.service.IClientService;

/**
 * @author voigi
 *
 */
@RestController
@RequestMapping("/client")
public class ClientController {

	@Autowired
	private IClientService clientService;

	@GetMapping("/all")
	public List<ClientDTO> getAllClients() {
		return ClientMapper.toDtoListWithContact(clientService.getAllClients());
	}

	@DeleteMapping("/{id}")
	public void deleteCustomer(@PathVariable long id) {
		clientService.deleteCustomer(id);
	}

}
