package com.example.client.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.client.core.domain.Client;
import com.example.client.core.repository.IClientRepository;
import com.example.client.service.IClientService;

@Service
public class ClientService implements IClientService {

	@Autowired
	private IClientRepository clientRepo;

	@Override
	public List<Client> getAllClients() {

		return clientRepo.findAll();
	}

	@Override
	public void deleteCustomer(long id) {
		clientRepo.deleteById(id);
	}

}
