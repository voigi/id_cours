package com.example.client.dto.mapper;

import java.util.ArrayList;
import java.util.List;

import com.example.client.core.domain.Contact;
import com.example.client.dto.ContactDTO;

public class ContactMapper {

	public static List<ContactDTO> toDtoList(List<Contact> contacts) {

		List<ContactDTO> contactDTOs = null;

		if (contacts != null && !contacts.isEmpty()) {
			contactDTOs = new ArrayList<>();
			for (Contact c : contacts) {
				contactDTOs.add(toDto(c));
			}
		}

		return contactDTOs;
	}

	public static ContactDTO toDto(Contact c) {
		ContactDTO contdto = null;

		if (c != null) {
			contdto = new ContactDTO(c.getId(), c.getValeur(), ContactTypeMapper.toDto(c.getType()));
		}

		return contdto;

	}
}
