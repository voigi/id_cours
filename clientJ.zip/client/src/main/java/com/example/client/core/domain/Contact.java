package com.example.client.core.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "contact_client")
public class Contact {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "coc_id")
	private Long id;

	@Column(name = "coc_valeur")
	private String valeur;

	@ManyToOne
	@JoinColumn(name = "cli_id", nullable = false)
	private Client client;

	@ManyToOne
	@JoinColumn(name = "tco_id", nullable = false)
	private ContactType type;

	public Contact() {
		super();

	}

	public Contact(Long id, String valeur, Client client, ContactType type) {
		super();
		this.id = id;
		this.valeur = valeur;
		this.client = client;
		this.type = type;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getValeur() {
		return valeur;
	}

	public void setValeur(String valeur) {
		this.valeur = valeur;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public ContactType getType() {
		return type;
	}

	public void setType(ContactType type) {
		this.type = type;
	}

}
