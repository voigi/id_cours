package com.example.client.dto.mapper;

import java.util.ArrayList;
import java.util.List;

import com.example.client.core.domain.Client;
import com.example.client.dto.ClientDTO;

public class ClientMapper {

	public static ClientDTO toDtoWithContact(Client cli) {
		ClientDTO cliDTO = null;

		if (cli != null) {
			cliDTO = toDto(cli);
			cliDTO.setContacts(ContactMapper.toDtoList(cli.getContacts()));
		}

		return cliDTO;
	}

	public static ClientDTO toDto(Client cli) {

		ClientDTO dto = null;

		if (cli != null) {
			dto = new ClientDTO(cli.getId(), cli.getNom(), cli.getPrenom(), cli.getAdresse(), cli.getPostal(),
					cli.getPays());
		}

		return dto;
	}

	public static List<ClientDTO> toDtoListWithContact(List<Client> allClients) {
		List<ClientDTO> cli = null;

		if (allClients != null && !allClients.isEmpty()) {
			cli = new ArrayList<>();

			for (Client c : allClients) {
				cli.add(toDtoWithContact(c));
			}
		}

		return cli;
	}

}
