package com.example.client.dto.mapper;

import com.example.client.core.domain.ContactType;
import com.example.client.dto.ContactTypeDTO;

public class ContactTypeMapper {

	public static ContactTypeDTO toDto(ContactType type) {
		ContactTypeDTO ctdto = null;

		if (type != null) {
			ctdto = new ContactTypeDTO(type.getId(), type.getLibelle());
		}

		return ctdto;

	}

}
